﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akshaya_Assesment
{
    public class MaxSumOfSubArray
    {
         public void Main()
        {
            Console.WriteLine("Enter the size of the array :");
            int ch = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[ch];
            Console.WriteLine("Enter the Elements :");
            for (int i = 0; i < ch; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }    
             MaxSum(array);
        }

        private void MaxSum(int[] array)
        {
            Dictionary<int, int[]> maxSum = new Dictionary<int, int[]>(); 
            int[] subArray = new int[3];
            //int max = 0;
            for(int i=0;i<array.Length;i++)
            {
                int k = 0;
                for(int j = i; j<3 && j<array.Length;j++)
                {
                    subArray[k] = Convert.ToInt32(Console.ReadLine());
                }
                int sum = 0;
                for(int p=0;p<3;p++)
                {
                    sum += subArray[p];
                }
                maxSum.Add(sum, subArray);
             }
            int m = 0;
            foreach (KeyValuePair<int, int[]> result in maxSum)
            {
                if (result.Key > m)
                {
                    m = result.Key;
                }
            }
            Console.WriteLine(maxSum[m]);

        }
    }
}
