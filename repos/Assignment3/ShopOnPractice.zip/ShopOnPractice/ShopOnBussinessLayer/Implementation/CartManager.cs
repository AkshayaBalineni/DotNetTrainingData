﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopOnBussinessLayer.Implementation
{
    class CartManager
    {
    }
}
