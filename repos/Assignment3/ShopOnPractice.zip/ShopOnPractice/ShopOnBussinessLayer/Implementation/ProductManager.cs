﻿using System;
using System.Collections.Generic;
using System.Text;
using ShopOnDataLayer.Implementation;
using ShopOnCommonLayer.Models;
namespace ShopOnBussinessLayer.Implementation
{
    public class ProductManager
    {
        ProductRepoInMemoryArray productRepo = new ProductRepoInMemoryArray();
        public bool AddProduct(Product product)
        {
            return productRepo.AddProduct(product);
        }

        public Product[] GetProducts()
        {
            return productRepo.GetProducts();
        }

        public Product GetProductById(int prodId)
        {
            return productRepo.GetProductById(prodId);
        }

        public bool UpdateProduct(Product updatedproduct)
        {
            return productRepo.UpdateProduct(updatedproduct);
        }

        public bool DeleteProduct(Product deleteProduct)
        {
            return productRepo.DeleteProduct(deleteProduct);
        }
    }
}
