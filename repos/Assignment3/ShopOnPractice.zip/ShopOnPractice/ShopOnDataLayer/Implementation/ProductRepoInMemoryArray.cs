﻿using System;
using System.Collections.Generic;
using System.Text;
using ShopOnCommonLayer.Models;

namespace ShopOnDataLayer.Implementation
{
    public class ProductRepoInMemoryArray
    {
        private int count = -1;
        private Product[] products = new Product[3];
        public bool AddProduct(Product product)
        {
            bool isInserted = false;
            if(count >= products.Length-1)
            {
                Product[] temp = new Product[products.Length];
                Array.Copy(products, temp, products.Length);
                products = new Product[products.Length * 2];
                Array.Copy(temp, products, temp.Length);
                temp = null;
            }
            products[++count] = product;
            isInserted = true;
            return isInserted;
        }
        public Product[] GetProducts()
        {
            Product[] temp = new Product[count+1];
            Array.Copy(products, temp, count+1);
            return temp;
        }
        public Product GetProductById(int prodId)
        {
           /* Product[] tempArr = new Product[count + 1];
            Array.Copy(products, tempArr, count + 1);*/
            Product temp = new Product();
            foreach(var product in products)
            {
                if (prodId == product.PId)
                {
                    temp = product;
                    break;
                }
            }
            return temp;
        }
        public bool UpdateProduct(Product updatedproduct)
        { int index = 0;
            foreach (var product in products)
            { 
                if (updatedproduct.PId == product.PId)
                {
                    products[index] = updatedproduct;
                    break;
                }
                index++;
            }
            return true;
        }
        public bool DeleteProduct(Product deleteProduct)
        {
           for(int i=0; i<count;i++)
            {
                if (products[i].PId == deleteProduct.PId)
                {
                    for(int j = i; j<count; j++)
                      products[j] = products[j + 1];
                }
            }
            count--;
            return true;
        }
    }
}
