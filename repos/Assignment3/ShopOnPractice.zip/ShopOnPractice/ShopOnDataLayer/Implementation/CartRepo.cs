﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopOnDataLayer.Implementation
{
    class CartRepo
    {

    }
}
