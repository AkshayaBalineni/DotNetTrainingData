﻿using ShoppingApplication;
using System;

namespace ShopOnConsoleApp
{
    class Program
    {
        static void Main()
        {
            new ProductMenu().Main();
            Console.ReadKey();
        }
    }
}
