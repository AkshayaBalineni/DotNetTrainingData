﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnConsoleApp
{
    class CartMenu
    {
        public void Main()
        {
            int ch = 0;
            bool looping = true;
            while (looping)
            {
                Console.WriteLine("CART MENU");
                Console.WriteLine("****************************");
                Console.WriteLine("1.ADD PRODUCT TO CART");
                Console.WriteLine("2.DISPLAYING CART ITEMS");
                Console.WriteLine("3.Delete Product");
                Console.WriteLine("Enter your choice");
                Console.WriteLine("****************************");
                ch = Convert.ToInt32(Console.ReadLine());

                switch(ch)
                {
                    case 1: AddProduct();
                            break;
                    case 2: DisplayProduct();
                            break;
                   
                default: looping = false; break;
            }
            Console.WriteLine("Do you want to continue? y/n");
            String s = Console.ReadLine();
            if (String.Equals(s, "N", StringComparison.OrdinalIgnoreCase))
                looping = false;
        }

            }

        private void DisplayProduct()
        {
            throw new NotImplementedException();
        }

        private void AddProduct()
        {
            throw new NotImplementedException();
        }
    }

}

