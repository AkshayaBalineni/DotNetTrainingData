﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShopOnBussinessLayer.Implementation;
using ShopOnCommonLayer.Models;

namespace ShoppingApplication
{
    public class ProductMenu
    {
        ProductManager productManager = new ProductManager();
        public void Main()
        {
            int ch = 0;
            bool looping = true;
            while (looping)
            {
                Console.WriteLine("PRODUCT MENU");
                Console.WriteLine("****************************");
                Console.WriteLine("1.ADD PRODUCT");
                Console.WriteLine("2.DISPLAY PRODUCT");
                Console.WriteLine("3.Get ProductById");
                Console.WriteLine("4.Update Product");
                Console.WriteLine("5.Delete Product");
                Console.WriteLine("Enter your choice");
                Console.WriteLine("****************************");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1: AddProduct(productManager); 
                            break;
                    case 2: DisplayProduct(productManager); 
                            break;
                    case 3: GetProductById(productManager);
                            break;
                    case 4: UpdateProduct(productManager);
                            break;
                    case 5: DeleteProduct(productManager);
                            break;
                    default: looping = false; break;
                }
                Console.WriteLine("Do you want to continue? y/n");
                String s = Console.ReadLine();
                if (String.Equals(s, "N", StringComparison.OrdinalIgnoreCase))
                   looping = false;
            }
        }
                    
        private void AddProduct(ProductManager productManager)
        {
            Product prod = new Product();
            Console.WriteLine("Enter the ProductId:");
            prod.PId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the ProductName:");
            prod.ProductName = Console.ReadLine();
            Console.WriteLine("Enter the ProductPrice:");
            prod.ProductPrice = Convert.ToDouble(Console.ReadLine());
            if (productManager.AddProduct(prod))
                Console.WriteLine("Product Saved");
            else
                Console.WriteLine("Product Not saved");
        }
        private void DisplayProduct(ProductManager productManager)
        {
            Console.WriteLine("List of Products");
            Console.WriteLine("************************************************");
            Console.WriteLine("ProductId\t\tProductName\t\tProductProce");
            Console.WriteLine("************************************************");
            foreach(var product in productManager.GetProducts())  
            {
                Console.WriteLine($"{product.PId}\t\t{product.ProductName}\t\t{product.ProductPrice}");
            }
        }

        private void GetProductById(ProductManager productManager)
        {
            Console.WriteLine("Enter the productId to be searched:");
            int prodId = Convert.ToInt32(Console.ReadLine());
            Product prod = productManager.GetProductById(prodId);
            Console.WriteLine("************************************************");
            Console.WriteLine("ProductId\t\tProductName\t\tProductProce");
            Console.WriteLine("************************************************");
            Console.WriteLine($"{prod.PId}\t\t{prod.ProductName}\t\t{prod.ProductPrice}");
        }

        private void UpdateProduct(ProductManager productManager)
        {
            Console.WriteLine("Enter the productId to be updated:");
            int prodId = Convert.ToInt32(Console.ReadLine());
            Product updatedproduct = productManager.GetProductById(prodId);
            Console.WriteLine("Enter the updated ProductName:");
            updatedproduct.ProductName = Console.ReadLine();
            Console.WriteLine("Enter the updated ProductPrice:");
            updatedproduct.ProductPrice = Convert.ToDouble(Console.ReadLine());
            if (productManager.UpdateProduct(updatedproduct))
                Console.WriteLine("Product updated");
            else
                Console.WriteLine("Product Not updated");
        }
        private void DeleteProduct(ProductManager productManager)
        {
            Console.WriteLine("Enter the productId to be deleted:");
            int prodId = Convert.ToInt32(Console.ReadLine());
            Product deleteProduct = productManager.GetProductById(prodId);
            if (productManager.DeleteProduct(deleteProduct))
                Console.WriteLine("Product deleted");
            else
                Console.WriteLine("Product Not deleted");

        }
    }
}

