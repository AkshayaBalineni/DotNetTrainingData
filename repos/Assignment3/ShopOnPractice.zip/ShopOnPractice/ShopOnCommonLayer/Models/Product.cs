﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopOnCommonLayer.Models
{
   public class Product
    {
        public int PId { get; set; }
        public String ProductName { get; set; }
        public Double ProductPrice { get; set; }
    }
}
