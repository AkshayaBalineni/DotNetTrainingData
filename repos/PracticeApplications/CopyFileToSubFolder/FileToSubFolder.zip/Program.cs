﻿using System;

namespace CopyFileToSubFolder
{
    public class Program
    {
        static void Main()
        {
            new FileToSubFolder().Main();
        }
    }
}
