﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class ArrayListDemo
    {
        public void Main()
        {
            ArrayList arrayList = new ArrayList();
            arrayList.Add(10);
            arrayList.Add("Shashi");
            arrayList.Add(30);

            foreach (var item in arrayList)
            {
                if(item is int)
                {

                }
                else if(item is string)
                {

                }
            }
        }
    }
}
