﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class CartManager
    {
        public void Main()
        {
            CartRepository cartRepository = new CartRepository();
            Cart cart1 = new Cart()
            {
               Name = "Cadbury Dairy Milk Silk Fruit and Nut Chocolate Bar, 55 g",
               Price = 78,
               ImageUrl = "Cadbury2.jpg",
               Qty = 1
            };
            Cart cart2 = new Cart()
             {
                 Name = "Cadbury Dairy Milk Silk Roast Almond Chocolate Bar, 58 g",
                 Price = 75,
                 ImageUrl = "Cadbury1.jpg",
                 Qty = 2
             };
            Cart cart3 = new Cart()
            {
                Name = "Cadbury Dairy Milk Silk Mousse Chocolate Bar, 50 g",
                Price = 148,
                ImageUrl = "Cadbury3.jpg",
                Qty = 1
            };

            cartRepository.AddCart(cart1);
            Console.WriteLine("After adding 1st product");
            DisplayCartItems(cartRepository);
            cartRepository.AddCart(cart2);
            Console.WriteLine("After adding 2nd product");
            DisplayCartItems(cartRepository);
            cartRepository.AddCart(cart3);
            Console.WriteLine("After adding 3rd product");
            DisplayCartItems(cartRepository);
            
        }

        private void DisplayCartItems(CartRepository cartRepository)
        {
            Console.WriteLine($"Cart Count {cartRepository.CartCnt}");
            Console.WriteLine($"Total Amount {cartRepository.CartTotal}");
        }
    }
}
