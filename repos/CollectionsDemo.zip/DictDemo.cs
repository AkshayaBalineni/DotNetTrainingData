﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class DictDemo
    {
        public void Main()
        {
            Dictionary<int, List<int>> report = new Dictionary<int, List<int>>();
            var studentID1 = 1001;
            List<int> markOfStudent1 = new List<int>()
            {
                45,
                56,
                67,
                78,
                90,
                98
            };

            report.Add(studentID1, markOfStudent1);
            var studentID2 = 1002;
            List<int> marksOfStudent2 = new List<int>()
            {
                23,
                45,
                56,
                23,
                67,
                78
            };
            report.Add(studentID2, marksOfStudent2);
            DisplayMarkReport(report);
        }

        private void DisplayMarkReport(Dictionary<int, List<int>> report)
        {
            //Console.WriteLine($"Student ID {report.Keys.}");
            int i = 0;
            foreach (var key in report.Keys)
            {
                Console.WriteLine($"Student ID {key}");
                var marks = report[key];
                foreach (var mark in marks)
                {
                    Console.WriteLine($"Mark OF Subject {++i} : {mark}");
                }
                i = 0;
                Console.WriteLine("------------------------------------------------");
            } 
        }
    }
}
