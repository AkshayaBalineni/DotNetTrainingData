﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class HashDemo
    {
        public void Main()
        {
            SortedSet<int> nos = new SortedSet<int>()
            {
                2, 5, 1, 6, 8, 9, 4
            };

            foreach (var no in nos)
            {
                Console.WriteLine(no);
            }

        }
    }
}
