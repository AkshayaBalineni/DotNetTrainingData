﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class ListDemo
    {
        public void Main()
        {
            //List<int> nos = new List<int>();
            //nos.Add(3);
            //nos.Add(5);
            //nos.Add(1);

            List<int> nos = new List<int>()
            {
                3, 2, 5, 6, 1, 8, 9, 10, 4, 7, 11
            };
            Dispaly(nos);
            nos.RemoveAt(4);
            Console.WriteLine("After removing data at position 4");
            Dispaly(nos);
            List<int> newNos = new List<int>()
            {
                21, 22, 23, 24, 25
            };
            nos.AddRange(newNos);
            Console.WriteLine("After adding range data");
            Dispaly(nos);
            //nos.Contains(10);
            nos.Sort();
            Console.WriteLine("After sorting");
            Dispaly(nos);
        }

        private static void Dispaly(List<int> nos)
        {
            Console.WriteLine($"Fetch {nos.Count} data from list");
            foreach (var no in nos)
            {
                Console.Write(no + " ");
            }
            Console.WriteLine();
        }
    }
}
