﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class DistDemo2
    {
        public void Main()
        {
            Dictionary<string, string> contacts = new Dictionary<string, string>();
            contacts.Add("Shashi", "8971472005");
            contacts.Add("Ravi", "8971473455");
            contacts.Add("Shankar", "89714723005");
            contacts.Add("Suman", "8971472054");
            contacts.Add("Raj", "8971472005");
            contacts.Add("Suraj", "8971472034");
        }
    }
}
