﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class LinkListDemo
    {
        public void Main()
        {
            LinkedList<int> nos = new LinkedList<int>();
            nos.AddLast(10);
            nos.AddFirst(1);
            
            
        }
    }
}
