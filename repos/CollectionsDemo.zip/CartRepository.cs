﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.CollectionDemos
{
    class CartRepository
    {
        // List<Cart> carts = new List<Cart>();
        ObservableCollection<Cart> carts = new ObservableCollection<Cart>();
        public int CartCnt { get; private set; }

        public double CartTotal { get; private set; }

        public void AddCart(Cart cart)
        {
            carts.Add(cart);
            carts.CollectionChanged += Carts_CollectionChanged;
        }

        private void Carts_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if(e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
            {
                CartCnt++;
            }
            else if(e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                CartCnt--;
            }
            GetCartTotal();
        }

       
        public void GetCartTotal()
        {
            double total = 0;
            foreach (var item in this.carts)
            {
                total += item.Price * item.Qty;
            }
            CartTotal =  total;
        }

        public void RemoveCart(int cartId)
        {

        }
    }
}
