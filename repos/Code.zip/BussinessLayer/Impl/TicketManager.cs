﻿using BussinessLayer.Contracts;
using CommonLayer;
using DataLayer.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLayer.Impl
{
    public class TicketManager : ITicketManager
    {
        private readonly ITicketRepo tickectRepo = null;

        public TicketManager(ITicketRepo ticketRepo)
        {
            this.tickectRepo = ticketRepo;
        }

        public string AddTicket(Ticket ticket)
        {
            return tickectRepo.AddTicket(ticket);
        }

        public IEnumerable<Ticket> ViewTicket(string EmployeeId)
        {
            return tickectRepo.ViewTicket(EmployeeId);
        }
    }
}
