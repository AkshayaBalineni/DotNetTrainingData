﻿using BussinessLayer.Contracts;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TickectManagementWebApp.Models;

namespace TickectManagementWebApp.Controllers
{
    public class TicketController : Controller
    {
        private readonly ITicketManager ticketManager;

        //userManager => manage user(Register)
        //singIn manager=> login/logout
        public TicketController(ITicketManager ticketManager)
        {
            this.ticketManager = ticketManager;
        }
        [HttpGet]
        public IActionResult LogTicket()
        {
            return View();
        }
        [HttpPost]
        public  IActionResult LogTicket(LogTicket Emp)
        {
            string id = "4";
            id = id + 1;
            if (ModelState.IsValid)
            {
                ticketManager.AddTicket(new CommonLayer.Ticket()
                {
                    TicketId = id.ToString(),
                    EmployeeId = Emp.EmployeeId,
                    RaisedDate = Emp.TicketDate,
                    TicketDesc = Emp.TicketDescription,
                    Severity = Emp.Severity
                }); 
                return RedirectToAction("Success", "Home",id.ToString());
            }

            return View(Emp);
        }
    }
}
