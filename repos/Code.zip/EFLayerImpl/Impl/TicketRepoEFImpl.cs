﻿using CommonLayer;
using DataLayer.Contracts;
using EFLayerImpl.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFLayerImpl.Impl
{
    public class TicketRepoEFImpl : ITicketRepo
    {
        private readonly db_TicketLoggingContext context;
        public TicketRepoEFImpl(db_TicketLoggingContext context)
        {
            this.context = context;
        }

        public string AddTicket(CommonLayer.Ticket ticket)
        {
            var dbTicket = new Models.Ticket()
            {
                TicketId = ticket.TicketId,
                LoggedBy = ticket.EmployeeId,
                RaisedDate = ticket.RaisedDate,
                Severity = ticket.Severity,
                TicketDescription = ticket.TicketDesc
            };
                this.context.Tickets.Add(dbTicket);
                context.SaveChanges();

            return ticket.TicketId;
         }

        public IEnumerable<CommonLayer.Ticket> ViewTicket(string EmployeeId)
        {
            List<CommonLayer.Ticket> tickets = new List<CommonLayer.Ticket>();
            var ticketsDb = this.context.Tickets.ToList();
            return tickets;
        }
    }
}
