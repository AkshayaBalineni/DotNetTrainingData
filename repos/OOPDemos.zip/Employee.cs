﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.OOPDemos
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }

        //public Address Address { get; set; }


        public Employee(Address address)
        {
            this.addresss.Add(address);
        }
      
        private List<Address> addresss = new List<Address>();

        public void AddAddress(Address address) 
        {
            this.addresss.Add(address);
        }

        public IEnumerable<Address> GetAddresses()
        {
            return this.addresss;
        }
       
        
    }
}
