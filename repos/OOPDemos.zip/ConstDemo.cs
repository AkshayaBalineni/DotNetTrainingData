﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.OOPDemos
{
    class Order
    {
        public int OrderId { get; }
        public int Pid { get; set; }
        public int Qty { get; set; }

        public Order(int orderId)
        {
            //if(orderId == 0)
            //{
            //    throw new Exception("Order id cannot be zero"); 
            //}
            Console.WriteLine("Const with 0 parameter called");
            this.OrderId = orderId;
        }

        public Order(int orderID, int Pid)
            : this(orderID)
        {
            Console.WriteLine("Const with 1 parameter called");
            this.Pid = Pid;
        }

        public Order(int orderID, int pid, int qty)
            : this(orderID, pid)
        {
            Console.WriteLine("Const with 2 parameter called");
            this.Qty = qty;
        }

    }


    class OrderDemo
    {
       
        public void Main()
        {
            
            Order order = new Order(1001);
            order.Pid = 1;
            order.Qty = 2;

            DisplayOrderDetails(order);

            Order order2 = new Order(100, 1);
            DisplayOrderDetails(order2);

            Order order3 = new Order(100, 1, 3);
            DisplayOrderDetails(order3);

            Order order4 = new Order(0, 0, 0);
            DisplayOrderDetails(order4);
        }

        private void DisplayOrderDetails(Order order)
        {
            //Console.WriteLine("Order ID " + order.OrderId + "\t PID " + order.Pid + "\t Qty " + order.Qty);
            //Console.WriteLine("Order ID {0} \t PID {1} \t Qty {2}",order.OrderId, order.Pid, order.Qty);
            Console.WriteLine($"Order ID {order.OrderId} \t PID {order.Pid} \t Qty {order.Qty}");
        }
    }
}
