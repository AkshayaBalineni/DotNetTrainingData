﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.OOPDemos
{
    public class EmployeeMain
    {
        public void Main()
        {
            //create Address
            Address address1 = new Address()
            {
                City = "Bangalore",
                State = "Karnataka"
            };

            //create Employee
            Employee employee = new Employee(address1)
            {
                EmployeeID = 1001,
                EmployeeName = "Sham"
            };

            

            //Address address2 = new Address()
            //{
            //    City = "Bangalore",
            //    State = "Karnataka"
            //};


            //List<Address> addresses = new List<Address>();
            //addresses.Add(address);
            //employee.Addresses = addresses;
            //add Address to Employee
            //employee.Address =  (address1);

            //add Employee to Address
            address1.Employee = employee;

            DisplayEmployeeData(employee);
            DisplayAddressData(address1);
        }

        private void DisplayAddressData(Address address)
        {
            Console.WriteLine("Address Details");
            Console.WriteLine($"City {address.City} \t State {address.State}");
            Console.WriteLine($"Employee ID {address.Employee.EmployeeID} \t" +
                $"Employee Name {address.Employee.EmployeeName}");
        }

        private void DisplayEmployeeData(Employee employee)
        {
            Console.WriteLine($"Employee ID {employee.EmployeeID} \t" +
                $"Employee Name {employee.EmployeeName}");
            Console.WriteLine("Address Info");
            //foreach (var address in employee.GetAddresses())
            //{
            //    Console.WriteLine($"City {address.City} \t State {address.State}");
            //}
            
        }
    }
}
