﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.OOPDemos
{
    public class SingleObj
    {
        private static SingleObj obj = new SingleObj();

        public static SingleObj Instance()
        {
            return obj;
        }

        private SingleObj()
        {

        }

        public void Display()
        {

        }
    }

    public class SingObjMain
    {
        public void Main()
        {
            SingleObj obj1 = SingleObj.Instance();
            obj1.Display();
        }
    }
}
