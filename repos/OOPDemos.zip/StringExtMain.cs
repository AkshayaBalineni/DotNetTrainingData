﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.OOPDemos
{
    class StringExtMain
    {

        public void Main()
        {
            string password = "shashi@2014";
            var encriptPassword = password.Encript();

            var decriptPassword = encriptPassword.DecryptString();
        }
    }
}
