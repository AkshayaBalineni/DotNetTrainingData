﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.OOPDemos
{
    class StaticDemo
    {
        int x = 0;          //instance
        static int y = 0;   //class

        static StaticDemo()
        {
            Console.WriteLine("Static const");
            y = 0;
        }

        public StaticDemo()
        {
            Console.WriteLine("Instance const");
        }

        //private StaticDemo()
        //{

        //}

        public static void StaticDisplay()
        {
            int z = 0;
            z++;
            Console.WriteLine($"Y {y} Z = {z}");
        }

        public void Dispaly()
        {
            int z = 0;
            x++;
            y++;
            z++;
            Console.WriteLine($"X : {x} \t Y : {y} \t Z : {z}");
        }

        public void Main()
        {
            StaticDemo staticDemo1 = new StaticDemo();
            StaticDemo staticDemo2 = new StaticDemo();

            staticDemo1.Dispaly();
            staticDemo2.Dispaly();
            staticDemo1.Dispaly();
            staticDemo2.Dispaly();

            //staticDemo1.StaticDisplay();
            StaticDemo.StaticDisplay();
            StaticDemo.StaticDisplay();
        }
    }
}
