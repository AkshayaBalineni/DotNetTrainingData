﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akshaya_Assessment2
{
    public class Address
    {
        public int AddressId { get; set; }
        public string State { get; set; }

    }
}
