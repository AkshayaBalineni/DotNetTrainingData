﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akshaya_Assessment2
{
    public class Customer : Person
    {
        public int CustomerId { get; set; }
        public DateTime Date{ get; set; }

    }
}
